DUCK BUDGET — LATEST RECOVERY BUILD

This restores the latest version we made in this chat:
- Home / Transactions / Bills / Planner / Goals tabs
- Duck assets instead of emoji category icons
- Heart coin asset support
- Custom sticker images for bottom navigation
- Debt Tracker inside Goals under the Demon Duck section
- Savings Goals under the Angel Duck section
- Paycheck Planner with duck category icons
- Local-only browser storage
- Backup / import tools
- PWA manifest + service worker + Android/iPad home-screen support
- Generated 180, 192 and 512 app-icon sizes
- Emoji-under-duck bug removed

UPLOAD STRUCTURE
Put index.html, manifest.json, and service-worker.js in the ROOT of the GitHub repo.
Keep the images folder in the ROOT as well.

IMPORTANT CUSTOM IMAGES
The latest index.html expects these files inside images/:
  heart-coin.png
  sticker-heart.png
  sticker-coin.png
  sticker-crown.png
  stickerbook-icon.png
  sticker-sparkles.png

Those six custom images were added directly to your GitHub repo after the earlier ZIP was uploaded to ChatGPT, so they are NOT duplicated in this recovery ZIP. If they are still in your repo, LEAVE THEM THERE. Uploading this recovery package through GitHub will not delete them.

The recovery ZIP DOES include:
  Angel-duck.PNG
  Burger-duck.PNG
  Demon-duck.PNG
  Fancy-duck.PNG
  Lemon-duck.PNG
  Party-hat-duck.PNG
  Standard-duck.PNG
  pile-of-tiny-ducks.png
  budgeticon.png
  budgeticon-180.png
  budgeticon-192.png
  budgeticon-512.png

ANDROID NOTE
After restoring the PWA files, Chrome may cache an old version. If needed, close old Duck Budget tabs and clear site data for peachiepeeps.github.io only AFTER exporting any important Duck Budget backup.
